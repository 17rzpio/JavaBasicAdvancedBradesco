package sistema;

public class BancoDeDados {
    public static String stringDeConexao = "jdbc:sqlserver://localhost:1433;databaseName=sistema_de_funcionarios";
    public static String usuario = "administrator";
    public static String senha = "admin";
}
